package bgu.spl.mics.application.messages;

import bgu.spl.mics.Event;

public class BombDestroyerEvent<Boolean> implements Event<Boolean> {


    public BombDestroyerEvent (){ }

}
