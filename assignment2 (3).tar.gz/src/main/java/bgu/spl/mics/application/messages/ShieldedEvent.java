package bgu.spl.mics.application.messages;

import bgu.spl.mics.Event;

public class ShieldedEvent implements Event<Boolean> {

    public ShieldedEvent () {}
}
